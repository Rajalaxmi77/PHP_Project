<?php
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $prodid=$_REQUEST['prodname'];
        $orderdate=$_REQUEST['orderdate'];
        $orderqty=$_REQUEST['orderqty'];
        $prodrate=$_REQUEST['unit_price'];
        $ordervalue = $prodrate * $orderqty;

        include 'config2.php';
        $sql="insert into order_master (product_id,order_date,order_qty) values('$prodid','$orderdate','$orderqty')";
            mysqli_query($conn,$sql);
            $flag=mysqli_affected_rows($conn);
            //echo $flag ,"  ",$sql;
            if($flag>0){
                echo "Saved successfull";
            }else{
                echo "failed";
            }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: pink;
            margin: 0;
            padding: 0;
        }

        form {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        div {
            margin-bottom: 15px;
        }

        span {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"],
        input[type="date"],
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #4caf50;
            color: #fff;
        }

    </style>
    <title>Order Management Form</title>
</head>
<body>
<form method="post">
    <div>
        <span>Product Name: <select name="prodname" id="prodname">
            <option hidden="hidden">Select Name</option>
             <?php
        include "config2.php";
        $sql=mysqli_query($conn,"select * from product_master");
        while($arr=mysqli_fetch_assoc($sql)):
            ?>
            <option value="<?php echo $arr["product_id"]; ?> "><?php echo $arr["name"]; ?> </option>
         <?php endwhile; ?>

        </select></span>
       
        
        <span>Order Date: <input type="date"  name="orderdate" id="orderdate" ></span>
        <span>Order Quantity: <input type="text" name="orderqty" id="orderqty"><span id="qty"></span></span>
        <span>Unit Price: <input type="text" name="unit_price" id="unit_price" readonly></span>
    </div>
    <input type="submit" name="btn" value="Save">
    <input type="submit" name="btn" value="Reset">
</form>
</body>
</html>


<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#prodname").blur(function(){
            $.ajax({
                url:"getprice.php",
                type:"POST",
                dataType:"JSON",
                data:{prodname:$("#prodname").val()},
                success:function(res){
                    json_text=JSON.stringify(res);
                    obj=JSON.parse(json_text);
                    $("#unit_price").val(obj.unit_price);
                    
                }
            })
        })
    })
    </script>
    <?php
        include 'config2.php';
        $sql=mysqli_query($conn,"select * from order_master INNER JOIN product_master ON order_master.product_id=product_master.product_id;");
        
        ?>


    <table border="1">
        <thead>
            <tr>
                <th>Sl NO</th>
                <th>product name</th>
                <th>order date</th>
                <th>order qty</th>
                <th>unit price</th>
                <th>order value</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
                <?php while ($row = mysqli_fetch_assoc($sql)) { ?>
                    <tr>
                        
                        <td><?php echo $row['order_id']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['order_date']; ?></td>
                        <td><?php echo $row['order_qty']; ?></td>
                        <td><?php echo $row['unit_price']; ?></td>
                        <td><?php echo $row['unit_price'] * $row['order_qty']; ?></td>
                        <td>
                    <button class="button button-primary">Edit</button>
                    <button onclick="deleteRow(<?php echo $row['order_id']; ?>)">Delete</button>
                </td>
                    </tr>
                <?php } ?>
            </tbody>
        
    </table>
