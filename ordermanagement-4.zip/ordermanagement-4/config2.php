<?php
$conn=mysqli_connect("localhost:3307","root","","assessment4");
    if(!$conn){
        die ("Connetion failed...");
    }
?>