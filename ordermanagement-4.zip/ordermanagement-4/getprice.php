<?php
$prodname=$_REQUEST["prodname"];
include "config2.php";
$r=mysqli_query($conn,"select * from product_master where product_id='$prodname'");
if($arr=mysqli_fetch_assoc($r)){
    echo json_encode($arr);
}
?>