<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (isset($_POST['btn'])) {
        $btn = $_POST['btn'];

        if ($btn == "Save Product") {
            // Validation checks and save product logic (unchanged)
            if (empty($_POST['prodname']) || empty($_POST['proddesc']) || empty($_POST['prodprice'])) {
                echo "Please fill in all the required fields.";
            } else {
                $prodname = strip_tags($_REQUEST['prodname']);
                $proddesc = $_REQUEST['proddesc'];
                $prodprice = $_REQUEST['prodprice'];

                if (isset($_POST['product_id']) && !empty($_POST['product_id'])) {
                    // Edit mode - update existing record
                    $id = $_POST['product_id'];
                    $sql = "UPDATE product_master SET name='$prodname', description='$proddesc', price='$prodprice' WHERE product_id=$id";
                } else {
                    // Insert mode - insert new record
                    $sql = "INSERT INTO product_master (name, description, price) VALUES ('$prodname', '$proddesc', '$prodprice')";
                }

                mysqli_query($con, $sql);
                $flag = mysqli_affected_rows($con);

                if ($flag > 0) {
                    echo "Operation successful";
                } else {
                    echo "Failed";
                }
            }
        }

        if ($btn == "Search") {
            $searchTerm = mysqli_real_escape_string($con, $_POST['search']);
            $res = mysqli_query($con, "SELECT * FROM product_master WHERE name LIKE '%$searchTerm%'");
        }

        if ($btn == "Cancel") {
            echo "Cancel button clicked.";
            echo "<script>document.getElementById('prodname').style.backgroundColor = '#000';</script>";
            echo "<script>document.getElementById('proddesc').style.backgroundColor = '#000';</script>";
            echo "<script>document.getElementById('prodprice').style.backgroundColor = '#000';</script>";
        }

        if ($btn == "delete") {
            $id = $_POST['product_id'];
            $sql = "DELETE FROM product_master WHERE product_id=$id";
            mysqli_query($con, $sql);
        }

        if ($btn == "edit") {
            $id = $_POST['product_id'];
            $res = mysqli_query($con, "SELECT * FROM product_master WHERE product_id='$id'");
            $arr = mysqli_fetch_assoc($res);
        }
    }
} else {
    // Load all products initially
    $res = mysqli_query($con, "SELECT * FROM product_master");
}
$entriesPerPage = 5;

// Calculate the total number of entries
$totalEntriesQuery = mysqli_query($con, "SELECT COUNT(*) AS total FROM product_master");
$totalEntries = mysqli_fetch_assoc($totalEntriesQuery)['total'];

// Calculate the total number of pages
$totalPages = ceil($totalEntries / $entriesPerPage);

// Get the current page
if (isset($_GET['page']) && is_numeric($_GET['page'])) {
    $currentPage = $_GET['page'];
} else {
    $currentPage = 1;
}
// Calculate the offset for the SQL query
$offset = ($currentPage - 1) * $entriesPerPage;


?>


<form action="" method="post">
    Product Name:<br>
    <input type="text" name="prodname" id="prodname" value="<?php echo isset($arr['name']) ? $arr['name'] : ''; ?>"><br>
    Product Description:<br>
    <input type="text" name="proddesc" id="proddesc" value="<?php echo isset($arr['description']) ? $arr['description'] : ''; ?>"><br>
    Product Price:<br>
    <input type="text" name="prodprice" id="prodprice" value="<?php echo isset($arr['price']) ? $arr['price'] : ''; ?>"><br>
    <input type="hidden" name="product_id" value="<?php echo isset($arr['product_id']) ? $arr['product_id'] : ''; ?>">
    <br>
    <input style="background-color: #28a745; color: #fff;" type="submit" name="btn" value="Save Product">
    <input style="background-color: #dc3545; color: #fff;" type="submit" name="btn" value="Cancel">
</form>
<!-- HTML Form for the search bar -->
<form action="" method="post">
    Search Product:<br>
    <input type="text" name="search" value="">
    <input type="submit" name="btn" value="Search">
</form>



<!-- Entries Per Page Dropdown -->
<form action="" method="post">
    Show entries:
    <select name="entriesPerPage" onchange="this.form.submit()">
        <option value="10" <?php echo ($entriesPerPage == 10) ? 'selected' : ''; ?>>10</option>
        <option value="20" <?php echo ($entriesPerPage == 20) ? 'selected' : ''; ?>>20</option>
        // Add more options as needed 
    </select>
</form>


<table border="1" width="50%">
    <thead>
        <tr>
            <th>Product_ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
    </thead>

    <?php
    if (isset($res)) {
        while ($arr = mysqli_fetch_assoc($res)) {
            echo "<tr>";
            echo "<td>{$arr['product_id']}</td>";
            echo "<td>{$arr['name']}</td>";
            echo "<td>{$arr['description']}</td>";
            echo "<td>{$arr['price']}</td>";
            echo "<td>";
            echo "<form action='' method='post'>";
            echo "<input type='hidden' name='product_id' value='{$arr['product_id']}'>";
            echo "<input type='submit' name='btn' value='delete'>";
            echo "</form>";
            echo "<form action='' method='post'>";
            echo "<input type='hidden' name='product_id' value='{$arr['product_id']}'>";
            echo "<input type='submit' name='btn' value='edit'>";
            echo "</form>";
            echo "</td>";
            echo "</tr>";
        }
    }
    ?>    
</table>

<!-- Pagination -->
<div>
    <?php
    echo "Showing " . (($currentPage - 1) * $entriesPerPage + 1) . " to " . min($currentPage * $entriesPerPage, $totalEntries) . " of $totalEntries entries";
    ?>

    <!-- Previous Page Link -->
    <?php if ($currentPage > 1): ?>
        <a href="?page=<?php echo ($currentPage - 1); ?>">Previous</a>
    <?php endif; ?>

    <!-- Page Numbers -->
    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
    <?php endfor; ?>

    <!-- Next Page Link -->
    <?php if ($currentPage < $totalPages): ?>
        <a href="?page=<?php echo ($currentPage + 1); ?>">Next</a>
    <?php endif; ?>
</div>


 