<?php

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (isset($_POST['btn'])) {
        $btn = $_POST['btn'];

        if ($btn == "Save Product") {
            // Validation checks and save product logic (unchanged)
            if (empty($_POST['prodname']) || empty($_POST['proddesc']) || empty($_POST['prodprice'])) {
                echo "Please fill in all the required fields.";
            } else {
                $prodname = strip_tags($_REQUEST['prodname']);
                $proddesc = $_REQUEST['proddesc'];
                $prodprice = $_REQUEST['prodprice'];

                if (isset($_POST['product_id']) && !empty($_POST['product_id'])) {
                    // Edit mode - update existing record
                    $id = $_POST['product_id'];
                    $sql = "UPDATE product_master SET name='$prodname', description='$proddesc', price='$prodprice' WHERE product_id=$id";
                } else {
                    // Insert mode - insert new record
                    $sql = "INSERT INTO product_master (name, description, price) VALUES ('$prodname', '$proddesc', '$prodprice')";
                }

                mysqli_query($con, $sql);
                $flag = mysqli_affected_rows($con);

                if ($flag > 0) {
                    echo "Operation successful";
                } else {
                    echo "Failed";
                }
            }
        }

        if ($btn == "Cancel") {
            echo "Cancel button clicked.";
            echo "<script>document.getElementById('prodname').style.backgroundColor = '#000';</script>";
            echo "<script>document.getElementById('proddesc').style.backgroundColor = '#000';</script>";
            echo "<script>document.getElementById('prodprice').style.backgroundColor = '#000';</script>";
        }

        if ($btn == "delete") {
            $id = $_POST['product_id'];
            $sql = "DELETE FROM product_master WHERE product_id=$id";
            mysqli_query($con, $sql);
        }

        if ($btn == "edit") {
            $id = $_POST['product_id'];
            $res = mysqli_query($con, "SELECT * FROM product_master WHERE product_id='$id'");
            $arr = mysqli_fetch_assoc($res);
        }
    }
} else {
    // Load all products initially
    $res = mysqli_query($con, "SELECT * FROM product_master");
}

?>
<!--  for the search bar and pegination  -->

    <script src="https://code.jquery.com/jquery-3.7.1.js"
        integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>

    <!-- DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">

    <!-- DataTables JS -->
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js">
    </script>

<form action="" method="post">
    Product Name:<br>
    <input type="text" name="prodname" id="prodname" value="<?php echo isset($arr['name']) ? $arr['name'] : ''; ?>"><br>
    Product Description:<br>
    <input type="text" name="proddesc" id="proddesc" value="<?php echo isset($arr['description']) ? $arr['description'] : ''; ?>"><br>
    Product Price:<br>
    <input type="text" name="prodprice" id="prodprice" value="<?php echo isset($arr['price']) ? $arr['price'] : ''; ?>"><br>
    <input type="hidden" name="product_id" value="<?php echo isset($arr['product_id']) ? $arr['product_id'] : ''; ?>">
    <br>
    <input style="background-color: #28a745; color: #fff;" type="submit" name="btn" value="Save Product">
    <input style="background-color: #dc3545; color: #fff;" type="submit" name="btn" value="Cancel">
</form>

<table  id="productTable" border="1" width="50%">
    <thead>
        <tr>
            <th>Product_ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
    </thead>

    <?php
    $res = mysqli_query($con, "SELECT * FROM product_master");
     while ($arr = mysqli_fetch_assoc($res)): ?>
        <tr>
            <td><?php echo $arr["product_id"]; ?></td>
            <td><?php echo $arr["name"]; ?></td>
            <td><?php echo $arr["description"]; ?></td>
            <td><?php echo $arr["price"]; ?></td>
            <td>
                <form action="" method="post">
                    <input type="hidden" name="product_id" value="<?php echo $arr['product_id']; ?>">
                    <input type="submit" name="btn" value="delete">
                </form>
                <form action="" method="post">
                    <input type="hidden" name="product_id" value="<?php echo $arr['product_id']; ?>">
                    <input type="submit" name="btn" value="edit">
                </form>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

<!-- Pagination -->

<script type="text/javascript">
    $(document).ready(function() {
        $('#productTable').DataTable();
    });
    </script>





 