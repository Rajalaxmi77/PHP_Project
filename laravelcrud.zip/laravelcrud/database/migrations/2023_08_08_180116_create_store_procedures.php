<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $stored_procedure="DROP PROCEDURE IF EXISTS `delete_users_by_id`;
       CREATE PROCEDURE `delete_users_by_id` (IN idx int)
       BEGIN
       delete from products where id=idx;
       END;";
       \DB::unprepared($stored_procedure); 
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('store_procedures');
    }
};
