<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</head>

</head>

<body>

<nav class="navbar navbar-expand-sm bg-dark">



<div class="container-fluid">

  <!-- Links -->

  <ul class="navbar-nav">

    <li class="nav-item">

      <a class="nav-link text-light" href="/">product</a>

    </li>

  </ul>

</div>



</nav>

<?php if($message=Session::get('success')): ?>

<div class="alert alert-success alert-block">

    <strong><?php echo e($message); ?></strong>

</div>

<?php endif; ?>

  <div class="container">

    <div class="row justify-content-center">

        <div class="col-sm-8">

            <div class="card mt-3 p-3">

            <form action="/products/<?php echo e($product->id); ?>/update" method="post" enctype="multipart/form-data">

                <?php echo csrf_field(); ?>

                <?php echo method_field('PUT'); ?>

                <div class="form-group">

                    <label for="" >Name</label>

                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name',$product->name)); ?>">



                    <?php if($errors->has('name')): ?>

                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>

                    <?php endif; ?>

                </div>

                <div class="form-group">

                    <label for="" >Description</label>

                    <textarea class="form-control" name="description" class="form-control" value="<?php echo e(old('description',$product->description)); ?>"></textarea>

                    <?php if($errors->has('description')): ?>

                    <span class="text-danger"><?php echo e($errors->first('description')); ?></span>

                    <?php endif; ?>

                </div>

                <div class="form-group">

                    <label for="" >image</label>

                    <input type="file" name="image" class="form-control">

                    <?php if($errors->has('image')): ?>

                    <span class="text-danger"><?php echo e($errors->first('image')); ?></span>

                    <?php endif; ?>

                </div>

                <button type="submit" class="btn btn-dark mt-2">submit</button>



            </form>

        </div>

        </div>

</div>

    </div>

   



</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravelcrud\resources\views/products/edit.blade.php ENDPATH**/ ?>