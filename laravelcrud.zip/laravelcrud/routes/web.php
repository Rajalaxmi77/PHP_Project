<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/get-procedure',function(){
    $id=3;
    $post=DB::select("CALL get_users_by_id(".$id.")");
    dd($post);
});
Route::get('/delete-procedure',function(){
    $id=3;
    $post=DB::select("CALL delete_users_by_id(".$id.")");
    dd("deleted");
});
Route::get('/insert-procedure',function(){
    $name="pinku";
    $des="heloo";
    $post=DB::select("CALL insert_users_by_id('$name','$des')");
    dd("inserted");
});








// Route::get('/',[ProductController::class,'index'])->name('products.index');
// Route::get('products/create',[ProductController::class,'create'])->name('products.create');
// Route::post('products/store',[ProductController::class,'store'])->name('products.store');



Route::get('/',[ProductController::class,'index'])->name('products.index');

Route::get('products/create',[ProductController::class,'create'])->name('products.create');

Route::post('products/store',[ProductController::class,'store'])->name('products.store');

Route::get('products/{id}/edit',[ProductController::class,'edit']);

Route::put('products/{id}/update',[ProductController::class,'update']);

Route::get('products/{id}/delete',[ProductController::class,'destroy']);





// Route::get('/', function () {
//     return view('welcome');
// });
