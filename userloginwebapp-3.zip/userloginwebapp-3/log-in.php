<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f4f4f4; /* Light gray background color */
        }

        .container {
            text-align: center;
            background-color: #fff; /* White background color */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Box shadow for a subtle effect */
        }

        form {
            display: inline-block;
            text-align: left;
        }

        h2 {
            color: #333; /* Dark gray text color */
        }

        input {
            margin: 5px 0;
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #007bff; /* Blue submit button color */
            color: #fff; /* White text color */
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Login Page</h2>
        <form method="post">
            User Name: <input type="text" name="name">
            <br><br>
            Password: <input type="password" name="password">
            <br>
            <br>
            <input type="submit" value="Login" name="btn">
        </form>
        <div class="signup-link">
            Don't have an account? <a href="sign-up.php">Sign Up</a>
        </div>
       
    </div>
</body>
</html>


<?php
  session_start();
  if($_SERVER['REQUEST_METHOD']=="POST")
  {
    include "config1.php";
    $user_name = $_POST['name'];
    $password = $_POST['password'];
    
    $sql="select * from user_master where user_name='$user_name' and password='$password'";
    $result=mysqli_query($conn,$sql);


        if($arr=mysqli_fetch_assoc($result))
        {
            $_SESSION['user_name']=$arr['user_name'];
            $_SESSION['password']=$arr['password'];
        
            if($arr['role_name']=="Student")
            {
                header('location:userhome.php');
            }
            
            if($arr['role_name']=="Admin")
            {
                header('location:adminhome.php');
            }
            }else{
            echo "invalid credntial";
        } 
}        
?>
