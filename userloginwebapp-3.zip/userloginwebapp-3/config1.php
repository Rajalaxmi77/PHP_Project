<?php
$conn=mysqli_connect("localhost:3307","root","","assessment3");
    if(!$conn){
        die ("Connetion failed...");
    }
    ?>