<?php 
session_start() ;
 ?>
<center> <h1> Admin Login Page</h1></center>
<center>
    <?php 
       $user_name=$_SESSION['user_name'];
       echo "<h2> Welcome Admin , ".$user_name."</h2>";
       ?>
</center>
<table border="1px" width="100%">
    <tr>
        <td> <b> User Name </b></td>
        <td> <b> Password </b></td>
        <td> <b> Role </b></td>
    </tr>
    <?php
    include "config1.php";
    $sql=mysqli_query($conn,"select * from user_master");
    while($arr=mysqli_fetch_assoc($sql)):
    ?>
    <tr>
    <td> <?php echo $arr['user_name']; ?> </td>
    <td> <?php echo $arr['password']; ?> </td>
    <td> <?php echo $arr['role_name']; ?> </td>
    </tr>
    <?php endwhile; ?>
</table>