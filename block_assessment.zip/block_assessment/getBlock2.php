<?php
include "config.php";
$blockid=$_REQUEST['b_id'];
$r=mysqli_query($con,"select * from panchayat where blockid in (select blockid from block where blockid='$blockid')");
$alldata=[];
// echo $alldata;
while($data=mysqli_fetch_assoc($r))
{
    array_push($alldata,$data);
}
echo json_encode($alldata);
?>