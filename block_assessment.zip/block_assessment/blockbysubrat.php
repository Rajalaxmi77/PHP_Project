<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    $("#b_id").change(() => {
        $.ajax({
            url: "getBlock2.php",
            type: "POST",
            dataType: "JSON",
            data: {
                b_id: $('#b_id').val()
            },
            success: (res) => {
                json_text = JSON.stringify(res);
                obj = JSON.parse(json_text);
                op = "";
                $.each(obj, (key, value) => {
                    op = op + "<option value=" + value.panchayatid + ">" + value
                        .panchayatname + "</option>";
                })
                $("#p_id").html(op);
            }
        })
    })
})
</script>

<form action="" method="post">
    Village Name : <input type="text" name="vname" id="v_id"><br><br>
    Total Population : <input type="text" name="tpname" id="tp_id"><br><br>
    Block: <select name="bname" id="b_id">
        <option value="" hidden="hidden">Choose..</option>
        <?php
                include "config.php";
                $sql="select * from block";
                $res=mysqli_query($con,$sql);
                while($arr=mysqli_fetch_assoc($res)):
            ?>
        <option value="<?php echo $arr["blockid"]; ?>"><?php echo $arr["blockname"]; ?></option>
        <?php endwhile; ?>
    </select>
    <br><br>
    Panchayat : <select name="pname" id="p_id">
    </select>
    <br><br>
    <input type="submit" name="btn" id="" value="Save">
</form>

<?php
        include 'config.php';
        if($_SERVER['REQUEST_METHOD']=="POST"){
            $vname=$_REQUEST['vname'];
            $tpname=$_REQUEST['tpname'];
            $bname=$_REQUEST['bname'];
            $pname=$_REQUEST['pname'];
            // echo $pname;
            $sql="insert into village(villagename,population,panchayatid) values ('$vname','$tpname','$pname')";
            mysqli_query($con,$sql);
            $flag=mysqli_affected_rows($con);
            //echo $flag;
            if($flag>0){
                echo "successfully entered";
            }else{
                echo "failed";
            }
            mysqli_close($con);
        }
    ?>

<h2>People Details</h2>
<table id="peopleTable" border="1" width="50%">
    <thead>
        <tr>
            <th>Sl No</th>
            <th>Village Name</th>
            <th>Population</th>
            <th>Panchayat Name</th>
            <th>Block Name</th>
        </tr>
    </thead>

    <tbody>
        <?php
            include "config.php";
            $res = mysqli_query($con, "SELECT
                                        v.villageid,
                                        v.villagename,
                                        v.population,
                                        p.panchayatname,
                                        b.blockname
                                        FROM
                                        village v
                                        JOIN
                                        panchayat p ON v.panchayatid = p.panchayatid
                                        JOIN
                                        block b ON p.blockid = b.blockid
                                        ORDER BY v.villageid ASC");
            $serialNumber = 1;                         
            while ($arr = mysqli_fetch_assoc($res)):
            ?>

        <form method="POST">
            <tr>
                <td>
                    <?php
                        echo $serialNumber++;
                    ?>
                </td>
                <td><?php echo $arr["villagename"]; ?></td>
                <td><?php echo $arr["population"]; ?></td>
                <td><?php echo $arr["panchayatname"]; ?></td>
                <td><?php echo $arr["blockname"]; ?></td>
            </tr>
        </form>

    </tbody>
    <?php endwhile; ?>
</table>