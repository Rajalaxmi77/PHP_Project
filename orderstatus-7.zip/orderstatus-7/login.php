<form action="adminpage.php" method="post">
    <input type="text" name="">
</form>