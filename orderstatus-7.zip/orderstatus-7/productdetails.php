<?php
include 'config.php';
if ($_SERVER['REQUEST_METHOD'] == "POST"){
    if ( $_POST['btn'] == "submit" ) {
        $productname=$_POST['productname'];
        $productdesc=$_POST['productdesc'];
        $prodprice=$_POST['prodprice'];
        $productqty=$_POST['productqty'];
        // $productimg = $_FILES['productimg']['name'];

        $sql="INSERT INTO productdetails (productname,productdesc,prodprice,productqty)values('$productname','$productdesc','$prodprice','$productqty')";
        mysqli_query($con, $sql);

        $flag = mysqli_affected_rows($con);

            if ($flag > 0) {
                echo "Operation successful";
            } else {
                echo "Failed";
            }       
    }    
}

?>
<form action="" method="post" >

    Product Name:
    <input type="text" name="productname">
    <br>
    Product Desc:
    <input type="text" name="productdesc">
    <br>
    Product Price:
    <input type="text" name="prodprice">
    <br>
    Product Qty:
    <input type="text" name="productqty">
    <br>
    <!-- Product Image:
    <input type="file" name="productimg">
    <br> -->
    <input type="submit" name="btn" value="submit">

</form>
<table border="1">
    <thead>
        <tr>
            <th>productname</th>
            <th>productdesc</th>
            <th>prodprice</th>
            <th>productqty</th>
        </tr>
    </thead>
    <?php
    include 'config.php';
    $res=mysqli_query($con,"SELECT * FROM productdetails ");
    while($arr=mysqli_fetch_assoc($res)):
    ?>
    <form action="" method="post">
            <tr>
                <td><?php echo $arr["productname"]; ?></td>
                <td><?php echo $arr["productdesc"]; ?></td>
                <td><?php echo $arr["prodprice"]; ?></td>
                <td><?php echo $arr["productdesc"]; ?></td>
            </tr>
    </form>
    <?php endwhile; ?>
                
</table>