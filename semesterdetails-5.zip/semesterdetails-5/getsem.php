<?php
$classid=$_REQUEST["classid"];
include "config.php";
$r=mysqli_query($con,"select * from semestermaster where classid='$classid'");
if($arr=mysqli_fetch_assoc($r)){
    echo json_encode($arr);
}
?>