<?php
include "config.php";

$sql="SELECT * FROM classmaster";
$result=mysqli_query($con,$sql);


?>


<form action="" method="post">
    Branch Name:
    <select>
        <?php while($row=mysqli_fetch_assoc($result)){ ?>

                <option value="<?php echo $row["classname"]; ?>"><?php echo $row['classname']; ?> </option>
                <?php   } ?>
            </select>
       <br><br>
       
    </select>
    <button type="submit">save</button>

</form>
<?php $select="SELECT * FROM classmaster"; ?>
<table border="1">
    <thead>
        <tr>
            <th>cid</th>
            <th>cname</th>
            <th>Action</th>
        </tr>
    </thead>
    <?php 
    include "config.php";
    while($row = @mysqli_fetch_assoc($select)){ ?>
    
        
        <tr>
            <td><?php echo $row["classid"]; ?></td>
            <td><?php echo $row["classname"]; ?></td>
            <td>
                <input type="hidden" name="id" value="<?php echo $arr['id']; ?>">
                    <input type="submit" name="btn" value="delete">
                    <input type="submit" name="btn" value="edit">
            </td>
        </tr>
    
    <?php } ?>
   
</table>