<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <title>Your Page Title</title>
</head>
<body>

<script type="text/javascript">
    $(document).ready(function(){
        $("#classid").blur(function(){
            $.ajax({
                url:"getsem.php",
                type:"POST",
                dataType:"JSON",
                data:{classid:$("#classid").val()},
                success:function(res){
                    json_text=JSON.stringify(res);
                    obj=JSON.parse(json_text);
                    $("#semid").val(obj.semid);
                }
            })
        })
    })

    function chk(){
        semid = parseInt(document.getElementById('semid').value);
        // You can add more validation or processing here
    }
</script>

<?php
include "config.php";

$sql="SELECT * FROM classmaster";
$result=mysqli_query($con,$sql);
?>

<form action="" method="post" onsubmit="return chk()">
    Class Name:
    <select name="classname" id="classid">
        <?php while($row=mysqli_fetch_assoc($result)){ ?>
            <option value="<?php echo $row["classname"]; ?>"><?php echo $row['classname']; ?></option>
        <?php } ?>
    </select>
    <br><br>
    Sem Name:
    <input type="text" readonly name="semname" id="semid">
    <br>
    <button type="submit">submit</button>
</form>

<?php
$select="SELECT * FROM classmaster";
$result_select = mysqli_query($con, $select);
$s="select * from semestermaster";
$r= mysqli_query($con, $s);
?>

<table border="1">
    <thead>
        <tr>
            <th>cid</th>
            <th>cname</th>
            <th>Sem Name</th>
            <th>Action</th>
        </tr>
    </thead>
    <?php while($row = mysqli_fetch_assoc($result_select)){ ?>
        <tr>
            <td><?php echo $row["classid"]; ?></td>
            <td><?php echo $row["classname"]; ?></td>
            
            <?php while($row = mysqli_fetch_assoc($r)){ ?> 
            
            <td><?php echo $row["semname"]; ?></td>
            <td>
                <input type="hidden" name="id" value="<?php echo $row['classid']; ?>">
                <input type="submit" name="btn" value="delete">
                <input type="submit" name="btn" value="edit">
            </td>
        </tr>
    
    <?php } ?>
    <?php } ?>
</table>

</body>
</html>
