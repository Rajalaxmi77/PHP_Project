<?php
if(isset($_REQUEST["b1"]))
{
    include "config.php";
    $image_data=addslashes(file_get_contents($_FILES["f"]["tmp_name"]));
    $image_name=$_FILES["f"]["name"];
    mysqli_query($con,"insert into user_profile(id,image_name,image_data)values(1,'$image_name','$image_data')");
    if( mysqli_affected_rows($con) >0 )
    {
        echo "success";
    }
    else{
        echo "failed";
    }
}

?>
<form enctype="multipart/form-data" method="post">
    <input type="file" name="f">
    <br>
    <input type="submit" name="b1" value="upload">
</form>
<?php
//display image in browser
include "config.php";
$result=mysqli_query($con,"select * from user_profile");
while($arr=mysqli_fetch_assoc($result))
{
    echo '<image src="data:image/jpeg;base64, '.base64_encode($arr["image_data"]).'">';
}