<?php
// $img=imagecreate(200,200);
// imagejpeg($img,"raja.jpg");
?>
<!-- <img src="raja.jpg" width="200" height="200" alt=""> -->

<?php
// $img=imagecreatefromjpeg('images/nokia.jpg');
// imagefilter($img,IMG_FILTER_NEGATE);
// imagejpeg($img,"raja.jpg");
?>
<!-- <img src="raja.jpg" width="200" height="200" alt=""> -->

<?php
// $s=imagecreatefromjpeg('images/nokia.jpg');
// $d=imagecreatefromjpeg('images/htc.jpg');
// imagecopymerge($d,$s,100,100,0,0,400,400,100);
// imagejpeg($d,"rani.jpg");
?>
<!-- <img src="rani.jpg" width="200" height="200" alt=""> -->

<?php
// $image=imagecreatefromjpeg("images/nokia.jpg");
// $t=imagecreatetruecolor(100,80);
// imagecopyresampled($t,$image,0,0,0,0,100,100,100,100);
// imagejpeg($t,"result.jpg",100);
?>
<!-- <img src="result.jpg" width="200px" height="200px" alt=""> -->


<!-- image uploading -->
<!-- <form action="up.php" method="post" enctype="multipart/form-data">
    choose an image:<input type="file" name="f">
    <br>
    <input type="submit" value="upload">
</form> -->
