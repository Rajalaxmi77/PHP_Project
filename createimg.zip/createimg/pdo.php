<?php
//print_r(PDO::getAvailableDrivers());

// $servername="localhost:3307";
// $username="root";
// $password="";
// try{
//     $con=new PDO("mysql:host=$servername;dbname=csm",$username,$password);
//     $con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
//     echo "connection successfull";
// }
// catch(PDOException $e){
//     echo "connection failed:".$e->getMessage();
// }
?>

<?php
//insert record in db using pdo.
// $servername="localhost:3307";
// $username="root";
// $password="";
// try{
//     include "config.php";
//     $con=new PDO("mysql:host=$servername;dbname=csm",$username,$password);
//     $con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
//     $sql="insert into practice(name,email)values('gunu','gunu@gmail.com')";
//     if($con->query($sql)){
//         echo "new record inserted";
//     }
//     else{
//         echo "data not inserted";
//     }
//     $con=null;
// }
// catch(PDOException $e){
//     echo $e->getMessage();
// }




//fetch records from a mysql db table and display in tabular format
?>
<table border="1">
    <tr>
        <th>Name</th>
        <th>Email</th>
    </tr>
    <?php
    $servername="localhost:3307";
$username="root";
$password="";

    
    $con=new PDO("mysql:host=$servername;dbname=csm",$username,$password);
    $con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    $result=$con->prepare("select * from practice order by id desc");
    $result->execute();
    for($i=0;$row=$result->fetch();$i++){
?>
<tr>
    <td><?php echo $row["name"];?></td>
    <td><?php echo $row["email"];?></td>
</tr>
<?php
    }
    ?>
</table>

