<?php
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    try {
        $pdo = new PDO("mysql:host=localhost:3307;dbname=csm", "root", "");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if ($_POST['btn'] == "register") {
            $name = strip_tags($_REQUEST['name']);
            $email = $_REQUEST['email'];

            $stmt = $pdo->prepare("INSERT INTO practice (name, email) VALUES ('$name', '$email')");
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':email', $email);
            $stmt->execute();

            $flag = $stmt->rowCount();

            if ($flag > 0) {
                echo "Registered successfully";
            } else {
                echo "Failed";
            }
        }

        if ($_POST['btn'] == "login") {
            $email = $_REQUEST['email'];
            $stmt = $pdo->prepare("SELECT * FROM practice WHERE email=:email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();

            $arr = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($arr["status"] == 1) {
                session_start();
                $_SESSION['name'] = $arr['name'];
                $_SESSION['email'] = $arr['email'];
            }
            echo "<br>Welcome To The Form, " . $_SESSION['name'];
        }

        if ($_POST['btn'] == "delete") {
            $id = $_POST['id'];
            $stmt = $pdo->prepare("DELETE FROM practice WHERE id=:id");
            $stmt->bindParam(':id', $id);
            $stmt->execute();
        }

        if ($_POST['btn'] == "edit") {
            $id = $_POST['id'];
            $stmt = $pdo->prepare("SELECT * FROM practice WHERE id=:id");
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            $arr = $stmt->fetch(PDO::FETCH_ASSOC);
        }

        if ($_POST['btn'] == "update") {
            $id = $_POST['id'];
            $name = strip_tags($_REQUEST['name']);
            $email = $_REQUEST['email'];

            $stmt = $pdo->prepare("UPDATE practice SET name=:name, email=:email WHERE id=:id");
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Example</title>
</head>
<body>
    <h2>Student Registration</h2>
    <form action="" method="post">
        Name: <input type="text" name="name" value="<?php echo isset($arr['name']) ? $arr['name'] : ''; ?>" required><br> <br>
        Email: <input type="text" name="email" value="<?php echo isset($arr['email']) ? $arr['email'] : ''; ?>" required ><br>
        <input type="hidden" name="id" value="<?php echo isset($arr['id']) ? $arr['id'] : ''; ?>"> <br>
        <div>
            <input type="submit" name="btn" value="update" style="background-color:pink">
            <input type="submit" name="btn" value="register" style="background-color:orange"> 
            <input type="submit" name="btn" value="login" style="background-color:skyblue"> 
        </div>
    </form><br>
    <h2>Student Details</h2>
    <table border="1" width="50%">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Action</th>
        </tr>

        <?php
        try {
            $pdo = new PDO("mysql:host=localhost:3307;dbname=csm", "root", "");
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $stmt = $pdo->query("SELECT * FROM practice");

            while ($arr = $stmt->fetch(PDO::FETCH_ASSOC)):
        ?>
            <form action="" method="post">
                <tr>
                    <td><?php echo $arr["name"]; ?></td>
                    <td><?php echo $arr["email"]; ?></td>
                    <td>
                        <input type="hidden" name="id" value="<?php echo $arr['id']; ?>">
                        <input type="submit" name="btn" value="delete" style="background-color:red">
                        <input type="submit" name="btn" value="edit" style="background-color:yellow">
                    </td>
                </tr>
            </form>
        <?php endwhile;
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
        ?>
    </table>
</body>
</html>