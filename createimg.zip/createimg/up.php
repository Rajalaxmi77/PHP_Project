<?php
$image=imagecreatefromjpeg($_FILES["f"]["tmp_name"]);
imagejpeg($image,"test.jpg",100);
?>
<img src="test.jpg" width="200px" height="200px" alt="">