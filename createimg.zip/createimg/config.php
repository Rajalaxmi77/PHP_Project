<?php
$con=mysqli_connect("localhost:3307","root","","csm");
    if(!$con){
        die("conn failed");
    }