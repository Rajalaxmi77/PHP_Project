 <script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#emp_id").change(function(){
            $.ajax({
                url:"getleave.php",
                type:"POST",
                dataType:"JSON",
                data:{emp_id:$("#emp_id").val()},
                success:function(res){
                    json_text=JSON.stringify(res);
                    obj=JSON.parse(json_text);
                    op="";
                    $.each(obj,function(key,value){
                        op=op+"<option value="+value.leave_id+">"+value.leave_name+"</option>";
                    })
                    $("#leave_id").html(op);
                    
                }
            })
        })
        $("#leave_id").change(function(){
            $.ajax({
                url:"get_no_of_leave.php",
                type:"POST",
                dataType:"JSON",
                data:{leave_id:$("#leave_id").val(),emp_id:$("#emp_id").val()},
                success:function(res){
                    $("#total").val(res.no_of_leave);
                }
            })
        })
    })

function chk() {
    total_id = parseInt(document.getElementById('total').value);
    apply_id = parseInt(document.getElementById('apply_id').value);
    if (apply_id <= total_id) {
        return true;
    } else {
        document.getElementById('msg').innerHTML = "Please enter fewer Number Of Leave";
        return false;
    }
}
 </script>

 <form action="" method="post" onsubmit="return chk();">
     Employee Name:<select name="emp_id" id="emp_id">
         <option hidden="hidden">Select Name</option>
         <?php
include "config1.php";
$r=mysqli_query($conn,"select * from employee");
while($arr=mysqli_fetch_assoc($r)):
    ?>
         <option value="<?php echo $arr["emp_id"]; ?> "><?php echo $arr["emp_name"]; ?> </option>
         <?php endwhile; ?>
     </select>
     <br>
     <br>
     Leave Apply:<select name="leave_id" id="leave_id"> </select>
     <input type="hidden" value="<?php echo $arr["leave_id"]; ?> ">
     <br>
     <br>
     Total No. Of Leave you have: <input type="text" name="total" id="total" readonly> <br>
     <br>
     Apply Leave: <input type="text" name="apply_id" id="apply_id" value="0"> <span id="msg"></span> <br> <br>

     <input type="submit" name="btn" value="Submit">
 </form>

 <?php
 include "config1.php";
if($_SERVER['REQUEST_METHOD']=="POST"){
    $emp_id=$_REQUEST['emp_id'];
    $leave_id=$_REQUEST['leave_id'];
    //$leave_Id="select leave_id from leave_master where leave_id='$leave_id'";
    $no_of_leave=$_REQUEST['apply_id'];

    $sql="insert into leave_apply (emp_id,leave_id,num_of_leave) 
    values ('$emp_id','$leave_id','$no_of_leave')";
    mysqli_query($conn,$sql);
    $flag=mysqli_affected_rows($conn);
    if($flag > 0){
        echo "  Inserted Successfully...","<br/>";
    }else
    {
        echo "failed to insert...";
    }
}
?>