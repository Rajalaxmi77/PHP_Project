<?php
include "config1.php";
$leave_id = $_REQUEST['leave_id'];
$emp_id=$_REQUEST['emp_id'];


$sql="select no_of_leave from leave_emp_assign where emp_id=$emp_id and leave_id=$leave_id";
$result=mysqli_query($conn,$sql);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    $totalLeave = $row['no_of_leave'];
    // echo "$totalLeave";
    echo json_encode(['no_of_leave' => $totalLeave]);
} else {
    echo json_encode(['error' => 'Failed to retrieve total leave']);            
}
?>