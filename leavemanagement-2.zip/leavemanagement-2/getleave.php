<?php
include "config1.php";
$emp_id=$_REQUEST['emp_id'];
$r=mysqli_query($conn,"select * from leave_master where leave_id in (select leave_id from leave_emp_assign where emp_id='$emp_id')");
$alldata=[];
while($data=mysqli_fetch_assoc($r))
{
    array_push($alldata,$data);
}
echo json_encode($alldata);
?>