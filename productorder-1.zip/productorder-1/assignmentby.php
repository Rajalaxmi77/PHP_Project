<?php 

include "config1.php";

$sql="SELECT * FROM product_master";
$result=mysqli_query($conn,$sql);

@include 'config1.php';

if(isset($_POST['add'])){

  @$productid=$_REQUEST['ProdID']; 
  @$orderqty=$_REQUEST['ProdQty'];
  @$ordervalue=$_REQUEST['OrderValue'];
  include_once 'config1.php';

  $sql="INSERT INTO order_master ( OrderID, ProdID, OrderQty,OrderValue,OrderDate) 
  VALUES ('','$productid','$orderqty','$ordervalue',NOW())";
  mysqli_query($conn,$sql);
  if(mysqli_affected_rows($conn)>0) {
    $message[] = 'please fill out all!';  
  } else{
    echo "some error!";
  }
}
$mydate= getdate(date("U"));
?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> -->
	<link rel="stylesheet" type="text/css" href="style.css"> 
	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="crossorigin="anonymous"></script>
	<title>Product Management System</title>
</head>
<body>
	<div class="container">
	<h1>Order Details</h1>
    <div class="admin-product-form-container">
    
     <form action="" method="post">
       
       Product Name :
       <select name="name" id="name" >
                <option selected>Select Product</option>

                <!-- =================for showing name============== -->
               <?php while($row=mysqli_fetch_assoc($result)){ ?>

                <option value="<?php echo $row["prodname"]; ?>"><?php echo $row['prodname']; ?> </option>
                <?php   } ?>
            </select>
       <br><br>
       
       Product Rate :
       <input type="number" class="box" name="unitprice" readonly id="unitprice" required />
       <br><br>
       Order Date:
       <input type="text" class="box" name="orderdate" id="orderdate" value="<?php echo "$mydate[weekday],$mydate[month],$mydate[mday],$mydate[year]"; ?>" readonly  required/>
       <br><br>
       Order Qty:
       <input type="number" min="0" class="box" name="productqty" id="productqty" onchange="sum()" required/>
       <input type="hidden" style="display: none;" name="productqtyOld" id="productqtyOld" /> 
       <input type="hidden" style="display: none;" name="productid" id="productid" />
       <input type="hidden" style="display: none;" name="unitprice" id="unitprice" />
       <br><br>
       Order Value: <input type="text" class="box" name="ordervalue" id="ordervalue" readonly required>
       <br /><br>
       <input type="submit" class="btnn" value="save" name="add" id="btn" disabled />
       <input type="reset" class="btn" value="reset" />
     </form> 
   
   </div>
 </div>

 <?php

 $select = mysqli_query($conn, "select * from order_master inner join product_master on order_master.ProdID=product_master.ProdID;");

 ?>
 <div class="product-display">
  <h1 align="center">List of Orders</h1>
  <center>
  <table class="product-display-table" border="" >
   <thead>
     <tr>
      <th>Order ID</th>
       <th>Order Date</th>
       <th>Product ID</th>
      <th>Product Name</th>
      <th>Product Rate</th>
      <th>Order Qty</th>
      <th>Order Value</th>
    </tr>
  </thead>
  <?php while($row = @mysqli_fetch_assoc($select)){ ?>
   <tr>
     <td><?php echo $row['orderid']; ?></td>
     <td><?php echo $row['orderdate']; ?></td>
     <td><?php echo $row['ProdID']; ?></td>
     <td><?php echo $row['ProdName']; ?></td>
     <td><?php echo $row['ProdRate']; ?></td>
     <td><?php echo $row['OrderQty']; ?></td>
     <td><?php echo $row['OrderValue']?></td>
   </tr>
 <?php } ?>

</table>
</center>
</div>
	<script type="text/javascript">
		  $(document).ready(function(){
		    $("#name").blur(function()
		    {
		      var errorproduct_qty = true;
		      function validproductqty(){
		        productqty = parseInt($('#productqty').val());
		        productqtyOld = parseInt($('#productqtyOld').val());
		        if (productqtyOld >= productqty) {
		          errorproductqty = true;
		        } else {
		          errorproductqty = false;
		        }
		      }
		      $("#btn").click(function(){
		        validproductqty();
		        if (errorproductqty) {
		          return true;
		        } else {
		          return false;
		        }
		      })
		      $.ajax({
		        type: "POST",
		        url: "search.php",
		        dataType: "JSON",
		        data: {name:$("#name").val()},
		        success:function(res){
		          if (res) {
		            $("#errorProductName").html("&#x2611;");
		            $("#unitprice").val(res.unitprice);
		            $("#productqtyOld").val(res.productqty);
		            $("#productid").val(res.productid);
		            $("#unitprice").val(res.unitprice);
		            $("#btn").attr("disabled", false);
		            
		          } else {
		            $("#errorProductName").html("product not aval !");
		            $("#unitprice").val("");
		            $("#productqtyOld").val("");
		            $("#productid").val("");
		            $("#unitprice").val("");
		            $("#btn").attr("disabled", true);

		          }
		        }
		      })

		    })

		  })

		  $("#form").validate({
		    rule:{
		      name:{
		       name:true
		     },
		     messages:{
		       required:'please enter product name'
		     }
		   }

		 });
	</script>
	<script type="text/javascript">
  function sum()
  {
    unitprice=$('#unitprice').val();
    productqty=$('#productqty').val();
    ordervalue=unitprice*productqty;
    $('#ordervalue').val(ordervalue);
  }
</script>
	<script src="main.js"></script>
</body>
</html> 
