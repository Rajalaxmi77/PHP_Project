<?php

    $prodid=$_REQUEST['prodid'];
    $prodrate=$_REQUEST['prodrate'];
    $orderqty=$_REQUEST['prodqty'];
    $ordervalue=$prodrate*$orderqty;
    include "config1.php";
    $sql="insert into order_master (prodid,prodrate,orderqty,ordervalue) values('$prodid','$prodrate','$orderqty','$ordervalue')";
    mysqli_query($conn,$sql);
    $flag=mysqli_affected_rows($conn);
    //echo $flag ,"  ",$sql;
    if($flag>0){
        echo "Saved successfull";
    }else{
        echo "failed";
    }
?>