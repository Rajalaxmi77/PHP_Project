<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#prodname").blur(function(){
            $.ajax({
                url:"getproduct.php",
                type:"POST",
                dataType:"JSON",
                data:{prodname:$("#prodname").val()},
                success:function(res){
                    json_text=JSON.stringify(res);
                    obj=JSON.parse(json_text);
                    $("#prodrate").val(obj.prodrate);
                     $("#oldprodqty").val(obj.prodqty);
                     $("#prodid").val(obj.prodid);
                }
            })
        })
    })
    function chk(){
        prodqty=parseInt(document.getElementById('prodqty').value);
        oldprodqty=parseInt(document.getElementById('oldprodqty').value);
        
        if(oldprodqty >=prodqty )
        {
            return true;
        }else{
            document.getElementById('qty').innerHTML="plz select less qty";
            return false;
        }
    }
</script>
<form action="order.php" method="post" onsubmit="return chk()">
Product Name:<input type="text" name="prodname" id="prodname">
<br>
Product Rate:<input type="text" readonly name="prodrate" id="prodrate">
<br>
Quantity:<input type="text" name="prodqty" id="prodqty"><span id="qty"></span>
<br>
<input type="hidden" name="oldprodqty" id="oldprodqty">
<input type="hidden" name="prodid" id="prodid">
<input type="submit" name="btn" value="order" >
</form>

<?php
include 'config1.php';

$select = mysqli_query($conn, "SELECT * FROM order_master INNER JOIN product_master ON order_master.prodid=product_master.prodid;");

// Check for errors
if (!$select) {
    die("Query failed: " . mysqli_error($conn));
}

?>

<div class="product-display">
    <h1 align="center">List of Orders</h1>
    <center>
        <table class="product-display-table" border="">
            <thead>
                <tr>
                    <th>Order Id</th>
                    <th>Product Name</th>
                    <th>Order Date</th>
                    <th>Order Qty</th>
                    <th>Product Rate</th>
                    <th>Order Value</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($select)) { ?>
                    <tr>
                        <td><?php echo $row['orderid']; ?></td>
                        <td><?php echo $row['prodname']; ?></td>
                        <td><?php echo $row['orderdate']; ?></td>
                        <td><?php echo $row['orderqty']; ?></td>
                        <td><?php echo $row['prodrate']; ?></td>
                        <td><?php echo $row['ordervalue']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </center>
</div>


    