<?php
$conn=mysqli_connect("localhost:3307","root","","assessment");
    if(!$conn){
        die ("Connetion failed...");
    }
    ?>