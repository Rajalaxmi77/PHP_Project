<?php
$con=mysqli_connect("localhost:3307","root","","block");
if(!$con){
    die("connection failed");
}
?>