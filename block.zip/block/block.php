<script type="text/javascript" src="jquery.js"> </script>
 <script type="text/javascript">
$(document).ready(function() {
    $("#blockid").change(function() {
        $.ajax({
            url: "getblock.php",
            type: "POST",
            dataType: "JSON",
            data: {
                blockid: $("#blockid").val()
            },
            success: function(res) {
                json_text = JSON.stringify(res);
                obj = JSON.parse(json_text);
                op = "";
                $.each(obj, function(key, value) {
                    op = op + "<option value='" + value.panchayatid + "'>" + value
                        .panchayatname + "</option>";
                })
                $("#panchayat").html(op);


            }
        })

    })
});
 </script>

 <!DOCTYPE html>
 <html lang="en">

 <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Block_Panchayat_Details</title>
     <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        form {
            max-width: 400px;
            margin: auto;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input,
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>

 </head>

 <body>
     <form action="" method="post">
         Village Name: <input type="text" name="villagename" id="villagename"> <br> <br>
         Total Population : <input type="text" name="population" id="population"> <br> <br>
         Block : <select name="blockid" id="blockid">
             <option hidden="hidden">--Select--</option>
             <?php
                include "config.php";
                $res=mysqli_query($con,"select * from block");
                while($arr=mysqli_fetch_assoc($res)):
             ?>
             <option value="<?php echo $arr["blockid"]; ?> "><?php echo $arr["blockname"]; ?> </option>
             <?php endwhile; ?>

         </select> <br> <br>
         Panchayat:<select name="panchayat" id="panchayat">
                        <option hidden="hidden">--Choose--</option>
                    </select> <br>
                    <input type="submit" value="Save" id="btn">
        </form>
     <?php
  include "config.php";
if($_SERVER['REQUEST_METHOD']=="POST")
{
    $villagename=$_REQUEST['villagename'];
    $population=$_REQUEST['population'];
    $panchayat=$_REQUEST['panchayat'];
   
    $sql="insert into village (villagename,population,panchayatid) 
    values ('$villagename','$population','$panchayat')";
    
    mysqli_query($con,$sql);
    $flag=mysqli_affected_rows($con);
    if($flag > 0){
        echo "  Inserted Successfully...","<br/>";
    }else
    {
        echo "failed to insert...";
    }
}
mysqli_close($con);
?>

     

 <h2>Village Details</h2>
<table border="1">
    <thead>
        <tr>
            <th>Sl No</th>
            <th>Village Name</th>
            <th>Population</th>
            <th>Panchayat Name</th>
            <th>Block Name</th>
        </tr>
    </thead>
    <tbody>
        <?php
        include "config.php";
        
        $query = "SELECT v.villageid, v.villagename, v.population, v.panchayatid, p.panchayatname, b.blockname
          FROM village v
          JOIN panchayat p ON v.panchayatid = p.panchayatid
          JOIN block b ON p.blockid = b.blockid
          ORDER BY v.villageid ASC";

        $res = mysqli_query($con, $query);
        while ($arr = mysqli_fetch_assoc($res)):
        ?>
            <tr>
                <td><?php echo $arr["villageid"]; ?></td>
                <td><?php echo $arr["villagename"]; ?></td>
                <td><?php echo $arr["population"]; ?></td>
                <td><?php echo $arr["panchayatname"]; ?></td>
                <td><?php echo $arr["blockname"]; ?></td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

